// -----------------------------

//          js index

// -----------------------------

//  push hover
//  countdown
//  jQuery MeanMenu
//  meanmenu
//  smooth scroll
//  masonry
//  countdown
//  fancybox
//  Ajax Contact Form
//  sticky
//  sticky for home 3

// -----------------------------


(function($){
    "use strict";



    /*----------------------------------
    push hover
    ------------------------------------*/
    $('.push').hover(function(){
        $(this).parent().addClass('speaker-info-click');
    });
    $('.pull').hover(function() {
        $(this).parentsUntil('speaker-info').removeClass('speaker-info-click');
    });


    /*----------------------------------
    countdown
    ------------------------------------*/
    $('#countdown3').ClassyCountdown({
        end: $.now() + 645600,
        now: $.now(),
        labels: true,
        labelsOptions: {
            style: 'font-size:0.4em; text-transform:uppercase;'
        },
        style: {
            element: "",
            textResponsive: .3,
            days: {
                gauge: {
                    thickness: .05,
                    fgColor: "rgb(241, 196, 15)"
                },
                textCSS: 'font-family:\'Open Sans\'; font-size:25px; font-weight:300; color:rgba(255,255,255,0.7);'
            },
            hours: {
                gauge: {
                    thickness: .05,
                    bgColor: "rgba(255,255,255,0.2)",
                    fgColor: "rgb(241, 196, 15)"
                },
                textCSS: 'font-family:\'Open Sans\'; font-size:25px; font-weight:300; color:rgba(255,255,255,0.7);'
            },
            minutes: {
                gauge: {
                    thickness: .05,
                    bgColor: "rgba(255,255,255,0.2)",
                    fgColor: "rgb(241, 196, 15)"
                },
                textCSS: 'font-family:\'Open Sans\'; font-size:25px; font-weight:300; color:rgba(255,255,255,0.7);'
            },
            seconds: {
                gauge: {
                    thickness: .05,
                    bgColor: "rgba(255,255,255,0.2)",
                    fgColor: "rgb(241, 196, 15)"
                },
                textCSS: 'font-family:\'Open Sans\'; font-size:25px; font-weight:300; color:rgba(255,255,255,0.7);'
            }

        },
        onEndCallback: function() {
            console.log("Time out!");
        }
    });

    /*----------------------------
     jQuery MeanMenu
    ------------------------------ */
    $('nav#dropdown').meanmenu();

    /*-----------------
    meanmenu 
    -----------------*/
    $('nav#mobile_menu_active').meanmenu({
        meanScreenWidth: "991",
        meanMenuContainer: '.mobile-menu-area .container',
    });



    /*----------------------------------
    smooth scroll
    ------------------------------------*/
    $('.smoothscroll').on('click', function(e) {
        e.preventDefault();
        var target = this.hash;

        $('html, body').stop().animate({
            'scrollTop': $(target).offset().top - 60
        }, 1200);
    });


    /*----------------------------------
    masonry
    ------------------------------------*/
    $('.portfolio-masonry').masonry({
        itemSelector: '.portfolio-item, .portfolio-grid'
    });

    /*---------------------
    countdown
    --------------------- */
    $('[data-countdown]').each(function() {
        var $this = $(this),
            finalDate = $(this).data('countdown');
        $this.countdown(finalDate, function(event) {
            $this.html(event.strftime('<span class="cdown days"><span class="time-count">%-D</span> <p>Days</p></span> <span class="cdown hour"><span class="time-count">%-H</span> <p>Hour</p></span> <span class="cdown minutes"><span class="time-count">%M</span> <p>Min</p></span> <span class="cdown second"> <span><span class="time-count">%S</span> <p>Sec</p></span>'));
        });
    });



    /*---------------------
    fancybox
    --------------------- */
    $('[data-fancybox]').fancybox({
        image: {
            protect: true
        }
    });

    /*---------------------
    // Ajax Contact Form
    --------------------- */

    $('.cf-msg').hide();
    $('form#cf button#submit').on('click', function() {
        var fname = $('#fname').val();
        var subject = $('#subject').val();
        var email = $('#email').val();
        var msg = $('#msg').val();
        var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;

        if (!regex.test(email)) {
            alert('Please enter valid email');
            return false;
        }

        fname = $.trim(fname);
        subject = $.trim(subject);
        email = $.trim(email);
        msg = $.trim(msg);

        if (fname != '' && email != '' && msg != '') {
            var values = "fname=" + fname + "&subject=" + subject + "&email=" + email + " &msg=" + msg;
            $.ajax({
                type: "POST",
                url: "mail.php",
                data: values,
                success: function() {
                    $('#fname').val('');
                    $('#subject').val('');
                    $('#email').val('');
                    $('#msg').val('');

                    $('.cf-msg').fadeIn().html('<div class="alert alert-success"><strong>Success!</strong> Email has been sent successfully.</div>');
                    setTimeout(function() {
                        $('.cf-msg').fadeOut('slow');
                    }, 4000);
                }
            });
        } else {
            $('.cf-msg').fadeIn().html('<div class="alert alert-danger"><strong>Warning!</strong> Please fillup the informations correctly.</div>')
        }
        return false;
    });


    /*-----------------
    sticky
    -----------------*/
    $(window).on('scroll', function() {
        if ($(window).scrollTop() > 170) {
            $('.menu-area').addClass('navbar-fixed-top');
        } else {
            $('.menu-area').removeClass('navbar-fixed-top');
        }
    });

    /*-----------------
    sticky for home 2
    -----------------*/
    $(window).on('scroll', function() {
        if ($(window).scrollTop() > 150) {
            $('.navbar-home2').addClass('navbar-fixed-top');
        } else {
            $('.navbar-home2').removeClass('navbar-fixed-top');
        }
    });

    /*-----------------
    sticky for home 3
    -----------------*/
    $(window).on('scroll', function() {
        if ($(window).scrollTop() > 640) {
            $('.h3-menu-area').addClass('navbar-fixed-top');
        } else {
            $('.h3-menu-area').removeClass('navbar-fixed-top');
        }
    });




})(jQuery);
